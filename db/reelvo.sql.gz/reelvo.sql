-- MySQL dump 10.13  Distrib 8.0.42, for Linux (x86_64)
--
-- Host: localhost    Database: reelvo
-- ------------------------------------------------------
-- Server version	8.0.42-0ubuntu0.24.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alembic_version`
--

DROP TABLE IF EXISTS `alembic_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alembic_version` (
  `version_num` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`version_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alembic_version`
--

LOCK TABLES `alembic_version` WRITE;
/*!40000 ALTER TABLE `alembic_version` DISABLE KEYS */;
INSERT INTO `alembic_version` VALUES ('de6f192e5b0d');
/*!40000 ALTER TABLE `alembic_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plans`
--

DROP TABLE IF EXISTS `plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plans` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` float NOT NULL,
  `weekly_ad_limit` int NOT NULL,
  `number_of_ads` int NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plans`
--

LOCK TABLES `plans` WRITE;
/*!40000 ALTER TABLE `plans` DISABLE KEYS */;
INSERT INTO `plans` VALUES (1,'Free',0,3,10,'2025-07-24 09:00:54','2025-07-24 09:00:54'),(2,'Starter',99,10,100,'2025-07-24 09:00:54','2025-07-24 09:00:54'),(3,'Basic',199,20,100,'2025-07-24 09:00:54','2025-07-24 09:00:54'),(4,'Pro',499,50,100,'2025-07-24 09:00:54','2025-07-24 09:00:54'),(5,'Business',999,100,100,'2025-07-24 09:00:54','2025-07-24 09:00:54');
/*!40000 ALTER TABLE `plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `progress_tasks`
--

DROP TABLE IF EXISTS `progress_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `progress_tasks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `task_id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int NOT NULL,
  `status` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `percent` int NOT NULL,
  `start_time` float NOT NULL,
  `elapsed` int NOT NULL,
  `download_url` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `task_id` (`task_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `progress_tasks_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `progress_tasks`
--

LOCK TABLES `progress_tasks` WRITE;
/*!40000 ALTER TABLE `progress_tasks` DISABLE KEYS */;
INSERT INTO `progress_tasks` VALUES (1,'da750ce9-61e8-4306-bc9d-cb6a3060dd17',1,'🎉 Reel is ready!<br>⏱️ Took 150.0 sec',100,1753360000,150,'https://reelvo.in/videos/developer@sazm.in/confidence_en_video.mp4','2025-07-24 11:28:27','2025-07-24 11:30:58'),(2,'2ee67aa3-0d57-4156-8a60-1c5b22d424ba',1,'🎉 Reel is ready!<br>⏱️ Took 354.0 sec',100,1753360000,354,'https://reelvo.in/videos/developer@sazm.in/moringa_hi_video.mp4','2025-07-24 11:35:29','2025-07-24 11:41:23'),(3,'0e04e83c-6026-40dd-9d54-d2ef4be68424',1,'🎉 Reel is ready!<br>⏱️ Took 110.0 sec',100,1753360000,110,'https://drive.google.com/uc?export=download&id=1IlV8modanN4kodhbvrSsVhN7ztaysMUt','2025-07-24 12:32:09','2025-07-24 12:34:00'),(4,'78022e7a-33fc-48a4-ac7d-57181f4c8602',1,'🎉 Reel is ready!<br>⏱️ Took 244.0 sec',100,1753370000,244,'https://reelvo.in/videos/developer@sazm.in/test_hi_video.mp4','2025-07-24 14:04:10','2025-07-24 14:08:15'),(5,'7c919729-1169-4253-a5c3-205302023ea3',2,'🎉 Reel is ready!<br>⏱️ Took 141.0 sec',100,1753370000,141,'https://reelvo.in/videos/shivamkumr132@gmail.com/motivation_en_video.mp4','2025-07-24 15:50:16','2025-07-24 15:52:38'),(6,'b576f150-dd17-4210-9233-5f99d7a671d2',2,'🎉 Reel is ready!<br>⏱️ Took 337.0 sec',100,1753370000,337,'https://reelvo.in/videos/shivamkumr132@gmail.com/fear_hi_video.mp4','2025-07-24 15:57:14','2025-07-24 16:02:52'),(7,'8f92a956-7829-423a-b488-17ac87cecbdc',1,'🎉 Reel is ready!<br>⏱️ Took 150.0 sec',100,1753380000,150,'https://reelvo.in/videos/developer@sazm.in/confidence_en_video.mp4','2025-07-24 18:25:06','2025-07-24 18:27:36'),(8,'c84c73fb-7c8c-421d-8ff8-7c28ca8b3922',4,'🎉 Reel is ready!<br>⏱️ Took 215.0 sec',100,1753420000,215,'https://reelvo.in/videos/kumdshivam524@gmail.com/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_hi_video.mp4','2025-07-25 04:53:11','2025-07-25 04:56:47'),(9,'e2def177-8631-4611-b01c-c087c67efdc3',4,'🎉 Reel is ready!<br>⏱️ Took 220.0 sec',100,1753430000,220,'https://reelvo.in/videos/kumdshivam524@gmail.com/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_product_hi_video.mp4','2025-07-25 06:32:07','2025-07-25 06:35:48'),(10,'738323b6-dc2c-4f22-8f23-eb994123c82d',1,'🎉 Reel is ready!<br>⏱️ Took 260.0 sec',100,1753430000,260,'https://reelvo.in/videos/developer@sazm.in/life_en_video.mp4','2025-07-25 07:28:34','2025-07-25 07:32:55'),(11,'aee67dbf-f298-4c06-a81d-f6361ffab497',4,'🎉 Reel is ready!<br>⏱️ Took 248.0 sec',100,1753430000,248,'https://reelvo.in/videos/kumdshivam524@gmail.com/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_hi_video.mp4','2025-07-25 08:54:27','2025-07-25 08:58:36'),(12,'5d101f35-3b52-4e0f-b2d1-c510ca8674dd',4,'🎉 Reel is ready!<br>⏱️ Took 324.0 sec',100,1753430000,324,'https://reelvo.in/videos/kumdshivam524@gmail.com/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_hi_video.mp4','2025-07-25 09:01:56','2025-07-25 09:07:20'),(13,'60405d4d-2e2f-485a-8d5a-45cbbb897d5a',4,'🎉 Reel is ready!<br>⏱️ Took 184.0 sec',100,1753450000,184,'https://reelvo.in/videos/kumdshivam524@gmail.com/fear_hi_video.mp4','2025-07-25 12:31:06','2025-07-25 12:34:11'),(14,'26208528-febf-4b46-8da2-fd01ba119341',4,'🎉 Reel is ready!<br>⏱️ Took 244.0 sec',100,1753450000,244,'https://reelvo.in/videos/kumdshivam524@gmail.com/fear_hi_video.mp4','2025-07-25 12:35:29','2025-07-25 12:39:34'),(15,'af585dcd-21e8-4903-a3cf-bf2cfa5df52b',5,'❌ Audio too short.<br>⏱️ Took 0.0 sec',0,1753450000,0,'','2025-07-25 14:48:24','2025-07-25 14:48:25'),(16,'2f4927c6-a3b0-4fad-a758-495ad9f51ef8',5,'🎉 Reel is ready!<br>⏱️ Took 48.0 sec',100,1753450000,48,'https://reelvo.in/videos/bharatjidubey021@gmail.com/confidence_hi_video.mp4','2025-07-25 14:49:51','2025-07-25 14:50:40'),(17,'c99749c3-ce09-4def-8a6b-ee71f9347c8e',5,'🎉 Reel is ready!<br>⏱️ Took 43.0 sec',100,1753460000,43,'https://reelvo.in/videos/bharatjidubey021@gmail.com/confidence_hi_video.mp4','2025-07-25 14:51:47','2025-07-25 14:52:31'),(18,'5075bfd4-94b1-4f2d-bb47-748335ac0006',1,'🎉 Reel is ready!<br>⏱️ Took 235.0 sec',100,1753480000,235,'https://reelvo.in/videos/developer@sazm.in/cosmetics_en_video.mp4','2025-07-25 21:18:26','2025-07-25 21:22:21'),(19,'d0d46b6a-a8e5-4ba7-96b2-3512129d37fb',1,'🎉 Reel is ready!<br>⏱️ Took 219.0 sec',100,1753480000,219,'https://reelvo.in/videos/developer@sazm.in/motivation_hi_video.mp4','2025-07-25 21:23:44','2025-07-25 21:27:24'),(20,'4cef8f28-d43e-4079-bac1-ada0a4bac2a1',1,'🎉 Reel is ready!<br>⏱️ Took 36.0 sec',100,1753480000,36,'https://reelvo.in/videos/developer@sazm.in/test_20250725213445_en_video.mp4','2025-07-25 21:34:45','2025-07-25 21:35:22'),(21,'e9a23fc1-42a7-4f5f-97a7-e4fb4f6ba13c',1,'🎉 Reel is ready!<br>⏱️ Took 155.0 sec',100,1753480000,155,'https://reelvo.in/videos/developer@sazm.in/motivation_20250725214117_en_video.mp4','2025-07-25 21:41:17','2025-07-25 21:43:52'),(22,'25c6ecaa-a741-44f9-b2ea-270dc01db0c6',1,'🎉 Reel is ready!<br>⏱️ Took 205.0 sec',100,1753480000,205,'https://reelvo.in/videos/developer@sazm.in/inspiration_20250725214540_hi_video.mp4','2025-07-25 21:45:40','2025-07-25 21:49:06'),(23,'6c8197a4-7844-4b41-87bc-a03c57cd84f7',1,'🎉 Reel is ready!<br>⏱️ Took 203.0 sec',100,1753480000,203,'https://reelvo.in/videos/developer@sazm.in/Moringa_20250725215231_en_video.mp4','2025-07-25 21:52:32','2025-07-25 21:55:55'),(24,'3a6af574-14d0-4c8c-b9e1-fe1ec90ec758',2,'🎉 Reel is ready!<br>⏱️ Took 238.0 sec',100,1753600000,238,'https://reelvo.in/videos/shivamkumr132@gmail.com/fear_20250727070736_hi_video.mp4','2025-07-27 07:07:37','2025-07-27 07:11:36'),(25,'784de06b-bddf-4521-a855-959c21531ca1',4,'🎉 Reel is ready!<br>⏱️ Took 165.0 sec',100,1753640000,165,'https://reelvo.in/videos/kumdshivam524@gmail.com/fear_20250727170354_hi_video.mp4','2025-07-27 17:03:54','2025-07-27 17:06:40'),(26,'a16bd6d5-ee81-4f5c-a4bb-af85a07409bf',4,'🎉 Reel is ready!<br>⏱️ Took 216.0 sec',100,1753640000,216,'https://reelvo.in/videos/kumdshivam524@gmail.com/fear_20250727170718_hi_video.mp4','2025-07-27 17:07:18','2025-07-27 17:10:55'),(27,'150252a4-dcaf-4823-9174-b2fec85fba6d',4,'🎉 Reel is ready!<br>⏱️ Took 173.0 sec',100,1753640000,173,'https://reelvo.in/videos/kumdshivam524@gmail.com/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_20250727171141_hi_video.mp4','2025-07-27 17:11:42','2025-07-27 17:14:36'),(28,'a8b43a94-498b-4483-a228-50995bdc87b9',4,'🎉 Reel is ready!<br>⏱️ Took 183.0 sec',100,1753680000,183,'https://reelvo.in/videos/kumdshivam524@gmail.com/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_20250728042241_hi_video.mp4','2025-07-28 04:22:41','2025-07-28 04:25:45'),(29,'f59ace7f-f7ce-4635-90a4-e19f21e080fa',4,'🎉 Reel is ready!<br>⏱️ Took 427.0 sec',100,1753680000,427,'https://reelvo.in/videos/kumdshivam524@gmail.com/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_20250728042809_hi_video.mp4','2025-07-28 04:28:10','2025-07-28 04:35:17'),(30,'3dd8191a-ace6-4861-8022-6f05bb9f825d',4,'🎉 Reel is ready!<br>⏱️ Took 180.0 sec',100,1753680000,180,'https://reelvo.in/videos/kumdshivam524@gmail.com/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_20250728043628_hi_video.mp4','2025-07-28 04:36:29','2025-07-28 04:39:30'),(31,'c544c95b-0892-49af-bf94-4534253ab98f',4,'🎉 Reel is ready!<br>⏱️ Took 121.0 sec',100,1753680000,121,'https://reelvo.in/videos/kumdshivam524@gmail.com/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_20250728044129_hi_video.mp4','2025-07-28 04:41:30','2025-07-28 04:43:31'),(32,'c563c197-2563-450f-99e9-0bd367043656',4,'🎉 Reel is ready!<br>⏱️ Took 186.0 sec',100,1753680000,186,'https://reelvo.in/videos/kumdshivam524@gmail.com/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_20250728053313_hi_video.mp4','2025-07-28 05:33:13','2025-07-28 05:36:20'),(33,'58527d96-6510-4bfa-8736-4b6a3bf0b105',4,'🎉 Reel is ready!<br>⏱️ Took 173.0 sec',100,1753770000,173,'https://reelvo.in/videos/kumdshivam524@gmail.com/fear_20250729060830_hi_video.mp4','2025-07-29 06:08:30','2025-07-29 06:11:24'),(34,'37e77cc5-4e16-4353-a690-0a3516872049',4,'🎉 Reel is ready!<br>⏱️ Took 254.0 sec',100,1753770000,254,'https://reelvo.in/videos/kumdshivam524@gmail.com/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_20250729064542_hi_video.mp4','2025-07-29 06:45:43','2025-07-29 06:49:57'),(35,'472489b5-d146-41c2-8f70-a3d677245061',4,'🎉 Reel is ready!<br>⏱️ Took 189.0 sec',100,1753780000,189,'https://reelvo.in/videos/kumdshivam524@gmail.com/MORINGA_power_ke_liye_advertiment_reel_20250729095922_en_video.mp4','2025-07-29 09:59:23','2025-07-29 10:02:32'),(36,'39a8641c-c837-4540-835c-ebe44b74a4f9',4,'🎉 Reel is ready!<br>⏱️ Took -2277.0 sec',100,1753940000,-2277,'https://reelvo.in/videos/kumdshivam524@gmail.com/discipline_20250731102211_hi_video.mp4','2025-07-31 04:52:12','2025-07-31 04:55:22'),(37,'86ae0136-b396-450e-81ad-3af5ef71fe7d',4,'🎉 Reel is ready!<br>⏱️ Took -1714.0 sec',100,1753940000,-1714,'https://reelvo.in/videos/kumdshivam524@gmail.com/discipline_20250731102949_hi_video.mp4','2025-07-31 04:59:50','2025-07-31 05:04:46');
/*!40000 ALTER TABLE `progress_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reels`
--

DROP TABLE IF EXISTS `reels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reels` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `title` text COLLATE utf8mb4_unicode_ci,
  `script` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `caption` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `video_path` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `audio_path` text COLLATE utf8mb4_unicode_ci,
  `thumbnail_path` text COLLATE utf8mb4_unicode_ci,
  `theme_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lang` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_scheduled` tinyint(1) NOT NULL,
  `scheduled_at` datetime DEFAULT NULL,
  `posted_at` datetime DEFAULT NULL,
  `platform` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `error_log` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_reels_schedule` (`is_scheduled`,`scheduled_at`),
  KEY `idx_reels_status` (`status`),
  KEY `idx_reels_user` (`user_id`),
  CONSTRAINT `reels_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `reels_chk_1` CHECK ((`status` in (_utf8mb4'draft',_utf8mb4'scheduled',_utf8mb4'posted',_utf8mb4'failed')))
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reels`
--

LOCK TABLES `reels` WRITE;
/*!40000 ALTER TABLE `reels` DISABLE KEYS */;
INSERT INTO `reels` VALUES (4,2,'Motivation','Ever feel like giving up? Like the world’s against you? Here’s the truth—every struggle is shaping you. Every setback is setting you up for a comeback. You’re stronger than you think, braver than you believe. This is your sign to keep going, to push harder, to rise higher. The world needs your fire—so don’t you dare dim your light. It’s not over until *you* win!','Ever feel like giving up? Like the world’s against you? Here’s the truth—every struggle is shaping you. Every setback is setting you up for a comeback. You’re stronger than you think, braver than you believe. This is your sign to keep going, to push harder, to rise higher. The world needs your fire—so don’t you dare dim your light. It’s not over until *you* win!','output/shivamkumr132@gmail.com/videos/motivation_en_video.mp4','output/shivamkumr132@gmail.com/temp/motivation_en_mixed.m4a','output/shivamkumr132@gmail.com/images/motivation_en_text_image.png','motivation','en',0,NULL,NULL,'instagram','draft',NULL,'2025-07-24 15:52:38','2025-07-24 15:52:38'),(5,2,'Fear','डर... ये वो शब्द है जो हमें रोकता है, हिलाता है, डराता है। लेकिन सच ये है—डर के आगे ही जीत है! जब तक तुम डर से भागोगे, वो तुम्हें पीछे खींचेगा। सीना तान कर सामना करो, कदम बढ़ाओ, और देखो... डर खुद तुमसे डरने लगेगा। क्योंकि जिसने डर को जीत लिया, उसकी जिंदगी ने जीतना सीख लिया!','डर... ये वो शब्द है जो हमें रोकता है, हिलाता है, डराता है। लेकिन सच ये है—डर के आगे ही जीत है! जब तक तुम डर से भागोगे, वो तुम्हें पीछे खींचेगा। सीना तान कर सामना करो, कदम बढ़ाओ, और देखो... डर खुद तुमसे डरने लगेगा। क्योंकि जिसने डर को जीत लिया, उसकी जिंदगी ने जीतना सीख लिया!','output/shivamkumr132@gmail.com/videos/fear_hi_video.mp4','output/shivamkumr132@gmail.com/temp/fear_hi_mixed.m4a','output/shivamkumr132@gmail.com/images/fear_hi_text_image.png','fear','hi',0,NULL,'2025-07-25 06:31:34','instagram','posted','Posted to IG: https://www.instagram.com/reel/DMhVJbNhAY8/','2025-07-24 16:02:52','2025-07-25 06:31:34'),(7,4,'Moriga Power Ke Liye Advertiment Jisshe Project Sell Ho','ज़िंदगी की हर चुनौती को हराने के लिए चाहिए मोरिगा पावर! प्रकृति का वरदान, सेहत का खज़ाना! हर बूंद में छुपी है ताकत, हर ड्रॉप में है एनर्जी का राज़! अब अपने प्रोजेक्ट को बनाएं हिट... मोरिगा पावर के साथ! जल्दी करें, ऑर्डर करें, और बेचें सुपरहिट! मोरिगा पावर – सेहत, ताकत, सफलता!','ज़िंदगी की हर चुनौती को हराने के लिए चाहिए मोरिगा पावर! प्रकृति का वरदान, सेहत का खज़ाना! हर बूंद में छुपी है ताकत, हर ड्रॉप में है एनर्जी का राज़! अब अपने प्रोजेक्ट को बनाएं हिट... मोरिगा पावर के साथ! जल्दी करें, ऑर्डर करें, और बेचें सुपरहिट! मोरिगा पावर – सेहत, ताकत, सफलता!','output/kumdshivam524@gmail.com/videos/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_hi_video.mp4','output/kumdshivam524@gmail.com/temp/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_hi_mixed.m4a','output/kumdshivam524@gmail.com/images/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_hi_text_image.png','moriga_power_ke_liye_advertiment_jisshe_project_sell_ho','hi',0,NULL,'2025-07-25 06:17:36','instagram','posted','Posted to IG: https://www.instagram.com/reel/DMhTi8ABjXb/','2025-07-25 04:56:47','2025-07-25 06:17:36'),(8,4,'Moriga Power Ke Liye Advertiment Jisshe Project Sell Ho Product','जब बिकनी है कोई बड़ी चीज़, तो बस एक ही नाम - मोरिगा पावर! ये नहीं, तो कुछ नहीं! हर प्रोडक्ट को बनाएं बेस्टसेलर, हर कैम्पेन को दें धमाल! क्योंकि यहाँ हर विज्ञापन में छुपी है जादू की छड़ी... देखिए, समझिए, और बदलिए अपनी मार्केटिंग गेम! मोरिगा पावर - जहाँ हर प्रोडक्ट बन जाता है सुपरहिट! ऑर्डर करें अभी!','जब बिकनी है कोई बड़ी चीज़, तो बस एक ही नाम - मोरिगा पावर! ये नहीं, तो कुछ नहीं! हर प्रोडक्ट को बनाएं बेस्टसेलर, हर कैम्पेन को दें धमाल! क्योंकि यहाँ हर विज्ञापन में छुपी है जादू की छड़ी... देखिए, समझिए, और बदलिए अपनी मार्केटिंग गेम! मोरिगा पावर - जहाँ हर प्रोडक्ट बन जाता है सुपरहिट! ऑर्डर करें अभी!','output/kumdshivam524@gmail.com/videos/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_product_hi_video.mp4','output/kumdshivam524@gmail.com/temp/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_product_hi_mixed.m4a','output/kumdshivam524@gmail.com/images/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_product_hi_text_image.png','moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_product','hi',0,NULL,'2025-07-25 06:50:10','instagram','posted','Posted to IG: https://www.instagram.com/reel/DMhXRldNMBB/','2025-07-25 06:35:48','2025-07-25 06:50:10'),(10,4,'Moriga Power Ke Liye Advertiment Jisshe Project Sell Ho','जिंदगी में कुछ बड़ा करना है? मौका चाहिए? ये प्रोजेक्ट आपकी ताकत बनने वाला है! हर सपने को पूरा करने का जज़्बा, हर मंज़िल तक पहुँचने का हौसला। यहाँ है वो मौका जिसका आपने इंतज़ार किया! जल्दी करें, समय कम है। आज ही जुड़ें और बन जाइए \'मोरिगा पावर\' का हिस्सा! बिक रहा है सपनों का ये प्रोजेक्ट—क्या आप तैयार हैं?','जिंदगी में कुछ बड़ा करना है? मौका चाहिए? ये प्रोजेक्ट आपकी ताकत बनने वाला है! हर सपने को पूरा करने का जज़्बा, हर मंज़िल तक पहुँचने का हौसला। यहाँ है वो मौका जिसका आपने इंतज़ार किया! जल्दी करें, समय कम है। आज ही जुड़ें और बन जाइए \'मोरिगा पावर\' का हिस्सा! बिक रहा है सपनों का ये प्रोजेक्ट—क्या आप तैयार हैं?','output/kumdshivam524@gmail.com/videos/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_hi_video.mp4','output/kumdshivam524@gmail.com/temp/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_hi_mixed.m4a','output/kumdshivam524@gmail.com/images/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_hi_text_image.png','moriga_power_ke_liye_advertiment_jisshe_project_sell_ho','hi',0,NULL,NULL,'instagram','draft',NULL,'2025-07-25 08:58:36','2025-07-25 08:58:36'),(11,4,'Moriga Power Ke Liye Advertiment Jisshe Project Sell Ho','जब दिल में जुनून हो, तो मुश्किलें छोटी पड़ जाती हैं! ये है \'मोरिगा पावर\' – आपकी सेहत का सुपरहीरो! हर बूंद में छुपी है असीम ऊर्जा, हर ड्रॉप में है जादू! प्रोजेक्ट सेल करना हो? मोरिगा पावर के साथ आगे बढ़ो, क्योंकि जब आप मजबूत, तो आपका बिज़नेस भी मजबूत! अभी ट्राई करो और महसूस करो फर्क! #MorigaPower #HealthMeetsSuccess','जब दिल में जुनून हो, तो मुश्किलें छोटी पड़ जाती हैं! ये है \'मोरिगा पावर\' – आपकी सेहत का सुपरहीरो! हर बूंद में छुपी है असीम ऊर्जा, हर ड्रॉप में है जादू! प्रोजेक्ट सेल करना हो? मोरिगा पावर के साथ आगे बढ़ो, क्योंकि जब आप मजबूत, तो आपका बिज़नेस भी मजबूत! अभी ट्राई करो और महसूस करो फर्क! #MorigaPower #HealthMeetsSuccess','output/kumdshivam524@gmail.com/videos/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_hi_video.mp4','output/kumdshivam524@gmail.com/temp/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_hi_mixed.m4a','output/kumdshivam524@gmail.com/images/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_hi_text_image.png','moriga_power_ke_liye_advertiment_jisshe_project_sell_ho','hi',0,NULL,NULL,'instagram','draft',NULL,'2025-07-25 09:07:20','2025-07-25 09:07:20'),(12,4,'Fear','डर... ये एक छाया की तरह हमेशा पीछे पड़ा रहता है। लेकिन जब तुम मुड़कर इसका सामना करते हो, ये सिकुड़ जाता है! डर को हराना नहीं, उसे जीतना है। क्योंकि जब तुम डर के आगे बढ़ते हो, तभी असली ताकत पाते हो! डर मत, आगे बढ़ो!','डर... ये एक छाया की तरह हमेशा पीछे पड़ा रहता है। लेकिन जब तुम मुड़कर इसका सामना करते हो, ये सिकुड़ जाता है! डर को हराना नहीं, उसे जीतना है। क्योंकि जब तुम डर के आगे बढ़ते हो, तभी असली ताकत पाते हो! डर मत, आगे बढ़ो!','output/kumdshivam524@gmail.com/videos/fear_hi_video.mp4','output/kumdshivam524@gmail.com/temp/fear_hi_mixed.m4a','output/kumdshivam524@gmail.com/images/fear_hi_text_image.png','fear','hi',0,NULL,'2025-07-25 12:40:39','instagram','posted','Posted to IG: https://www.instagram.com/reel/DMh_YA-onpo/','2025-07-25 12:34:11','2025-07-25 12:40:39'),(13,4,'Fear','डर... ये वो दीवार है जो हमें खुद से दूर कर देती है। लेकिन सोचो, अगर हम इस दीवार को पार कर लें? डर के आगे जीत है, हार नहीं! हर कदम पर वो तुम्हें रोकेगा, लेकिन याद रखो—जो डर से लड़ता है, वही जीतता है। तो आज ही वादा करो... डर को अपने सपनों का रास्ता नहीं रोकने दोगे। क्योंकि तुम... तुमसे बड़ा कोई डर नहीं!','डर... ये वो दीवार है जो हमें खुद से दूर कर देती है। लेकिन सोचो, अगर हम इस दीवार को पार कर लें? डर के आगे जीत है, हार नहीं! हर कदम पर वो तुम्हें रोकेगा, लेकिन याद रखो—जो डर से लड़ता है, वही जीतता है। तो आज ही वादा करो... डर को अपने सपनों का रास्ता नहीं रोकने दोगे। क्योंकि तुम... तुमसे बड़ा कोई डर नहीं!','output/kumdshivam524@gmail.com/videos/fear_hi_video.mp4','output/kumdshivam524@gmail.com/temp/fear_hi_mixed.m4a','output/kumdshivam524@gmail.com/images/fear_hi_text_image.png','fear','hi',0,NULL,'2025-07-25 12:42:37','instagram','posted','Posted to IG: https://www.instagram.com/reel/DMh_m5lBhg-/','2025-07-25 12:39:34','2025-07-25 12:42:37'),(14,5,'Confidence','Badmoshi nhi mitrr... Soo jao','Badmoshi nhi mitrr... Soo jao','output/bharatjidubey021@gmail.com/videos/confidence_hi_video.mp4','output/bharatjidubey021@gmail.com/temp/confidence_hi_mixed.m4a','output/bharatjidubey021@gmail.com/images/confidence_hi_text_image.png','confidence','hi',0,NULL,NULL,'instagram','draft',NULL,'2025-07-25 14:50:40','2025-07-25 14:50:40'),(15,5,'Confidence','Badmoshi nhi mitrr... Soo jao','Badmoshi nhi mitrr... Soo jao','output/bharatjidubey021@gmail.com/videos/confidence_hi_video.mp4','output/bharatjidubey021@gmail.com/temp/confidence_hi_mixed.m4a','output/bharatjidubey021@gmail.com/images/confidence_hi_text_image.png','confidence','hi',0,NULL,NULL,'instagram','draft',NULL,'2025-07-25 14:52:31','2025-07-25 14:52:31'),(16,1,'Motivation 20250725214117','Ever feel like giving up? Like the world’s got too much weight? Stop. Breathe. This is your sign—keep going! Every struggle is a step closer to strength. Every setback? A setup for a comeback. You’re not stuck. You’re just getting ready. So rise up. Push harder. The world needs your fire. Now go—outwork doubt, outshine fear, and own your greatness. This is your moment. *Seize it.*','Ever feel like giving up? Like the world’s got too much weight? Stop. Breathe. This is your sign—keep going! Every struggle is a step closer to strength. Every setback? A setup for a comeback. You’re not stuck. You’re just getting ready. So rise up. Push harder. The world needs your fire. Now go—outwork doubt, outshine fear, and own your greatness. This is your moment. *Seize it.*','output/developer@sazm.in/videos/motivation_20250725214117_en_video.mp4','output/developer@sazm.in/temp/motivation_20250725214117_en_mixed.m4a','output/developer@sazm.in/images/motivation_20250725214117_en_text_image.png','motivation_20250725214117','en',0,NULL,'2025-07-26 03:30:36','instagram','posted','Posted to IG: https://www.instagram.com/reel/DMjlOcYICkk/','2025-07-25 21:43:52','2025-07-26 03:30:36'),(17,1,'Inspiration 20250725214540','हर बड़ी कहानी एक सपने से शुरू होती है। चमकने के लिए किसी की इजाज़त मत लो। ये सफ़र तुम्हारा है — इसे अपनाओ। अपनी चिंगारी खुद बनो। और याद रखो — अंधेरे में ही सितारे सबसे तेज़ चमकते हैं। मुश्किल वक्त ही तुम्हारी असली पहचान बनाता है।','हर बड़ी कहानी एक सपने से शुरू होती है। चमकने के लिए किसी की इजाज़त मत लो। ये सफ़र तुम्हारा है — इसे अपनाओ। अपनी चिंगारी खुद बनो। और याद रखो — अंधेरे में ही सितारे सबसे तेज़ चमकते हैं। मुश्किल वक्त ही तुम्हारी असली पहचान बनाता है।','output/developer@sazm.in/videos/inspiration_20250725214540_hi_video.mp4','output/developer@sazm.in/temp/inspiration_20250725214540_hi_mixed.m4a','output/developer@sazm.in/images/inspiration_20250725214540_hi_text_image.png','inspiration_20250725214540','hi',0,NULL,'2025-07-26 02:30:37','instagram','posted','Posted to IG: https://www.instagram.com/reel/DMjeXA5uh3L/','2025-07-25 21:49:06','2025-07-26 02:30:37'),(18,1,'Moringa 20250725215231','Meet nature’s powerhouse—Moringa! Packed with vitamins, minerals, and antioxidants, this tiny leaf is a giant for your health. Boost energy, fight inflammation, and glow from within. Supercharge your day the natural way! Ready to feel unstoppable? Moringa’s got your back. 🌿💪 #MoringaMagic #SuperfoodPower','Meet nature’s powerhouse—Moringa! Packed with vitamins, minerals, and antioxidants, this tiny leaf is a giant for your health. Boost energy, fight inflammation, and glow from within. Supercharge your day the natural way! Ready to feel unstoppable? Moringa’s got your back. 🌿💪 #MoringaMagic #SuperfoodPower','output/developer@sazm.in/videos/Moringa_20250725215231_en_video.mp4','output/developer@sazm.in/temp/Moringa_20250725215231_en_mixed.m4a','output/developer@sazm.in/images/Moringa_20250725215231_en_text_image.png','Moringa_20250725215231','en',0,NULL,'2025-07-26 01:30:34','instagram','posted','Posted to IG: https://www.instagram.com/reel/DMjXf0BJQtB/','2025-07-25 21:55:55','2025-07-26 01:30:34'),(19,2,'Fear 20250727070736','डर... वो छोटा सा शब्द जो हमें रोक देता है, पीछे खींच लेता है। लेकिन सच ये है, डर खुद नहीं, बल्कि हमारी सोच है! आज ही पूछो खुद से—क्या डर के आगे झुकोगे या डर को पीछे छोड़ आगे बढ़ोगे? जिंदगी बड़ी है, डर से बड़ी! लड़ो, जीतो, और खुद को साबित करो!','डर... वो छोटा सा शब्द जो हमें रोक देता है, पीछे खींच लेता है। लेकिन सच ये है, डर खुद नहीं, बल्कि हमारी सोच है! आज ही पूछो खुद से—क्या डर के आगे झुकोगे या डर को पीछे छोड़ आगे बढ़ोगे? जिंदगी बड़ी है, डर से बड़ी! लड़ो, जीतो, और खुद को साबित करो!','output/shivamkumr132@gmail.com/videos/fear_20250727070736_hi_video.mp4','output/shivamkumr132@gmail.com/temp/fear_20250727070736_hi_mixed.m4a','output/shivamkumr132@gmail.com/images/fear_20250727070736_hi_text_image.png','fear_20250727070736','hi',0,NULL,'2025-07-28 14:21:27','instagram','posted','Posted to IG: https://www.instagram.com/reel/DMpThl7PQZM/','2025-07-27 07:11:36','2025-07-28 08:51:27'),(20,4,'Fear 20250727170354','डर... ये एक छोटा सा शब्द, पर इसकी छाया इतनी बड़ी। क्या तुमने कभी सोचा, ये डर किसका है? तुम्हारा या उनका जो तुम्हें डरा कर रखना चाहते हैं? डर को पहचानो, उसका सामना करो। क्योंकि जब तुम डर के आगे खड़े हो जाते हो, तो डर खुद पीछे हट जाता है। आज ही वादा करो, डर को अपनी ताकत बनाओ। जीत तुम्हारी होगी!','डर... ये एक छोटा सा शब्द, पर इसकी छाया इतनी बड़ी। क्या तुमने कभी सोचा, ये डर किसका है? तुम्हारा या उनका जो तुम्हें डरा कर रखना चाहते हैं? डर को पहचानो, उसका सामना करो। क्योंकि जब तुम डर के आगे खड़े हो जाते हो, तो डर खुद पीछे हट जाता है। आज ही वादा करो, डर को अपनी ताकत बनाओ। जीत तुम्हारी होगी!','output/kumdshivam524@gmail.com/videos/fear_20250727170354_hi_video.mp4','output/kumdshivam524@gmail.com/temp/fear_20250727170354_hi_mixed.m4a','output/kumdshivam524@gmail.com/images/fear_20250727170354_hi_text_image.png','fear_20250727170354','hi',0,NULL,'2025-07-27 17:11:48','instagram','posted','Posted to IG: https://www.instagram.com/reel/DMnoAp-srwG/','2025-07-27 17:06:40','2025-07-27 17:11:48'),(21,4,'Fear 20250727170718','**\"डर... ये वो दीवार है जो हमें खुद से दूर कर देती है। लेकिन जब तुम इसका सामना करते हो, ये दीवार खुद ब खुद गिर जाती है। डर को मत भगाओ, उससे लड़ो! क्योंकि जीत नहीं, हार नहीं... सिर्फ एक चीज़ मायने रखती है—तुम्हारी हिम्मत! डर के आगे झुकने से बेहतर है, डर को ही अपने आगे झुका दो!\"**','**\"डर... ये वो दीवार है जो हमें खुद से दूर कर देती है। लेकिन जब तुम इसका सामना करते हो, ये दीवार खुद ब खुद गिर जाती है। डर को मत भगाओ, उससे लड़ो! क्योंकि जीत नहीं, हार नहीं... सिर्फ एक चीज़ मायने रखती है—तुम्हारी हिम्मत! डर के आगे झुकने से बेहतर है, डर को ही अपने आगे झुका दो!\"**','output/kumdshivam524@gmail.com/videos/fear_20250727170718_hi_video.mp4','output/kumdshivam524@gmail.com/temp/fear_20250727170718_hi_mixed.m4a','output/kumdshivam524@gmail.com/images/fear_20250727170718_hi_text_image.png','fear_20250727170718','hi',0,NULL,NULL,'instagram','draft',NULL,'2025-07-27 17:10:55','2025-07-27 17:10:55'),(22,4,'Moriga Power Ke Liye Advertiment Jisshe Project Sell Ho 20250727171141','जब बात हो मोरिगा पावर की, तो सिर्फ़ विज्ञापन नहीं, जुनून चाहिए! हर प्रोजेक्ट को बनाओ हिट, हर क्लाइंट को दो यकीन! यहाँ नहीं होता समझौता, बस बेस्ट से बेस्ट परफॉर्मेंस! मोरिगा पावर के साथ अपने ब्रांड को दिलाओ नई पहचान, क्योंकि यहाँ हर कैम्पेन बनता है वायरल! समय आ गया है बेचने का... समय आ गया है चमकने का!','जब बात हो मोरिगा पावर की, तो सिर्फ़ विज्ञापन नहीं, जुनून चाहिए! हर प्रोजेक्ट को बनाओ हिट, हर क्लाइंट को दो यकीन! यहाँ नहीं होता समझौता, बस बेस्ट से बेस्ट परफॉर्मेंस! मोरिगा पावर के साथ अपने ब्रांड को दिलाओ नई पहचान, क्योंकि यहाँ हर कैम्पेन बनता है वायरल! समय आ गया है बेचने का... समय आ गया है चमकने का!','output/kumdshivam524@gmail.com/videos/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_20250727171141_hi_video.mp4','output/kumdshivam524@gmail.com/temp/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_20250727171141_hi_mixed.m4a','output/kumdshivam524@gmail.com/images/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_20250727171141_hi_text_image.png','moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_20250727171141','hi',0,NULL,NULL,'instagram','draft',NULL,'2025-07-27 17:14:36','2025-07-27 17:14:36'),(23,4,'Moriga Power Ke Liye Advertiment Jisshe Project Sell Ho 20250728042241','जब ताकत चाहिए, तो \'मोरिगा\' ही क्यों? क्योंकि ये सिर्फ एक पाउडर नहीं, सेहत का पावरहाउस है! हर चमच में छुपा है असली एनर्जी का राज़। प्रोजेक्ट सेल करना हो या दिनभर एक्टिव रहना हो, \'मोरिगा\' आपका साथ देगा! नेचुरल, पौष्टिक, और जबरदस्त! आज ही ट्राई करो और फर्क महसूस करो। \'मोरिगा\' – जिंदगी की असली ताकत!','जब ताकत चाहिए, तो \'मोरिगा\' ही क्यों? क्योंकि ये सिर्फ एक पाउडर नहीं, सेहत का पावरहाउस है! हर चमच में छुपा है असली एनर्जी का राज़। प्रोजेक्ट सेल करना हो या दिनभर एक्टिव रहना हो, \'मोरिगा\' आपका साथ देगा! नेचुरल, पौष्टिक, और जबरदस्त! आज ही ट्राई करो और फर्क महसूस करो। \'मोरिगा\' – जिंदगी की असली ताकत!','output/kumdshivam524@gmail.com/videos/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_20250728042241_hi_video.mp4','output/kumdshivam524@gmail.com/temp/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_20250728042241_hi_mixed.m4a','output/kumdshivam524@gmail.com/images/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_20250728042241_hi_text_image.png','moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_20250728042241','hi',0,NULL,NULL,'instagram','draft',NULL,'2025-07-28 04:25:45','2025-07-28 04:25:45'),(24,4,'Moriga Power Ke Liye Advertiment Jisshe Project Sell Ho 20250728042809','जो दिखे नामुमकिन, वो करके दिखाएँ! मोरिगा पावर के साथ कोई लक्ष्य हो बड़ा, कोई सपना हो ऊँचा—हम आपके हौसले को बनाते हैं हकीकत! चाहे हो प्रोजेक्ट, चाहे हो कोई बड़ा मिशन, हमारे साथ बिकेगा हर विजन! क्योंकि यहाँ हर चुनौती मिलती है मुकाबला, और हर सपना होता है पूरा! मोरिगा पावर—जहाँ विश्वास बनता है सफलता!','जो दिखे नामुमकिन, वो करके दिखाएँ! मोरिगा पावर के साथ कोई लक्ष्य हो बड़ा, कोई सपना हो ऊँचा—हम आपके हौसले को बनाते हैं हकीकत! चाहे हो प्रोजेक्ट, चाहे हो कोई बड़ा मिशन, हमारे साथ बिकेगा हर विजन! क्योंकि यहाँ हर चुनौती मिलती है मुकाबला, और हर सपना होता है पूरा! मोरिगा पावर—जहाँ विश्वास बनता है सफलता!','output/kumdshivam524@gmail.com/videos/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_20250728042809_hi_video.mp4','output/kumdshivam524@gmail.com/temp/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_20250728042809_hi_mixed.m4a','output/kumdshivam524@gmail.com/images/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_20250728042809_hi_text_image.png','moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_20250728042809','hi',0,NULL,'2025-07-28 16:35:37','instagram','posted','Posted to IG: https://www.instagram.com/reel/DMpi458s1Mg/','2025-07-28 04:35:17','2025-07-28 11:05:37'),(25,4,'Moriga Power Ke Liye Advertiment Jisshe Project Sell Ho 20250728043628','जब बात हो मोरिगा पावर की, तो बस एक ही नाम - [Your Brand Name]! हमारे प्रोडक्ट्स हैं असली गेम-चेंजर, इतने पावरफुल कि हर प्रोजेक्ट सेल हो जाएगा! कोई कमी नहीं, बस शानदार परफॉरमेंस! चाहे बड़ा काम हो या छोटा, हमारी ताकत आपके साथ! तो फिर क्या सोच रहे हो? आज ही जुड़िए [Your Brand Name] के साथ और बनाइए हर प्रोजेक्ट को हिट! मोरिगा पावर, बस और बस आपके लिए!','जब बात हो मोरिगा पावर की, तो बस एक ही नाम - [Your Brand Name]! हमारे प्रोडक्ट्स हैं असली गेम-चेंजर, इतने पावरफुल कि हर प्रोजेक्ट सेल हो जाएगा! कोई कमी नहीं, बस शानदार परफॉरमेंस! चाहे बड़ा काम हो या छोटा, हमारी ताकत आपके साथ! तो फिर क्या सोच रहे हो? आज ही जुड़िए [Your Brand Name] के साथ और बनाइए हर प्रोजेक्ट को हिट! मोरिगा पावर, बस और बस आपके लिए!','output/kumdshivam524@gmail.com/videos/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_20250728043628_hi_video.mp4','output/kumdshivam524@gmail.com/temp/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_20250728043628_hi_mixed.m4a','output/kumdshivam524@gmail.com/images/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_20250728043628_hi_text_image.png','moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_20250728043628','hi',0,NULL,'2025-07-28 16:28:59','instagram','posted','Posted to IG: https://www.instagram.com/reel/DMpiHuLtveq/','2025-07-28 04:39:30','2025-07-28 10:58:59'),(26,4,'Moriga Power Ke Liye Advertiment Jisshe Project Sell Ho 20250728044129','जब बात हो मोरीगा पावर की, तो कोई कम्प्रोमाइज़ नहीं! ये है वो अड्वरटाइमेंट जो आपके प्रोडक्ट को बनाएगी हिट! भावनाओं से जोड़े, दिलों में उतारे, और बिक्री के नए रिकॉर्ड तोड़े। मोरीगा पावर – क्योंकि आपका ब्रांड डिसर्व करता है बेस्ट! तैयार हो जाइए, क्योंकि अब बदलने वाली है आपकी मार्केटिंग गेम!','जब बात हो मोरीगा पावर की, तो कोई कम्प्रोमाइज़ नहीं! ये है वो अड्वरटाइमेंट जो आपके प्रोडक्ट को बनाएगी हिट! भावनाओं से जोड़े, दिलों में उतारे, और बिक्री के नए रिकॉर्ड तोड़े। मोरीगा पावर – क्योंकि आपका ब्रांड डिसर्व करता है बेस्ट! तैयार हो जाइए, क्योंकि अब बदलने वाली है आपकी मार्केटिंग गेम!','output/kumdshivam524@gmail.com/videos/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_20250728044129_hi_video.mp4','output/kumdshivam524@gmail.com/temp/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_20250728044129_hi_mixed.m4a','output/kumdshivam524@gmail.com/images/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_20250728044129_hi_text_image.png','moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_20250728044129','hi',0,NULL,'2025-07-28 16:22:40','instagram','posted','Posted to IG: https://www.instagram.com/reel/DMphZpHB-V2/','2025-07-28 04:43:31','2025-07-28 10:52:40'),(27,4,'Moriga Power Ke Liye Advertiment Jisshe Project Sell Ho 20250728053313','जब तुम्हारी मेहनत में हो मोरिगा पावर, तो दुनिया देखती है तुम्हारा जादू! ये है वो खास प्रोडक्ट जिसे बेचने के लिए चाहिए ज़बरदस्त एडवरटाइज़मेंट! हर क्लिक, हर व्यू, हर सेल – यहाँ छुपा है सफलता का राज! अब नहीं रुकना, बस बढ़ते जाना! क्योंकि जब हो तैयारी इतनी धाकड़, तो मार्केट में मचेगी धूम! लोगों को दिखाओ तुम्हारी ताकत... मोरिगा पावर के साथ बेचो अपने सपने, क्योंकि अब हर प्रोजेक्ट बनेगा हिट!','जब तुम्हारी मेहनत में हो मोरिगा पावर, तो दुनिया देखती है तुम्हारा जादू! ये है वो खास प्रोडक्ट जिसे बेचने के लिए चाहिए ज़बरदस्त एडवरटाइज़मेंट! हर क्लिक, हर व्यू, हर सेल – यहाँ छुपा है सफलता का राज! अब नहीं रुकना, बस बढ़ते जाना! क्योंकि जब हो तैयारी इतनी धाकड़, तो मार्केट में मचेगी धूम! लोगों को दिखाओ तुम्हारी ताकत... मोरिगा पावर के साथ बेचो अपने सपने, क्योंकि अब हर प्रोजेक्ट बनेगा हिट!','output/kumdshivam524@gmail.com/videos/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_20250728053313_hi_video.mp4','output/kumdshivam524@gmail.com/temp/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_20250728053313_hi_mixed.m4a','output/kumdshivam524@gmail.com/images/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_20250728053313_hi_text_image.png','moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_20250728053313','hi',0,NULL,'2025-07-28 14:22:07','instagram','posted','Posted to IG: https://www.instagram.com/reel/DMpTmlcNFOY/','2025-07-28 05:36:20','2025-07-28 08:52:07'),(28,4,'Fear 20250729060830','डर... वो छोटा सा शब्द जो हमें रोक देता है, पीछे खींच लेता है। लेकिन सुनो, डर हार नहीं है, डर तो बस एक चुनौती है! जब तक तुम हार नहीं मानते, तब तक तुम हारे नहीं हो। डर के आगे बढ़ो, उससे लड़ो, क्योंकि जीत उसी की होती है जो डर को हरा देता है। डरो मत, उड़ान भरो!','डर... वो छोटा सा शब्द जो हमें रोक देता है, पीछे खींच लेता है। लेकिन सुनो, डर हार नहीं है, डर तो बस एक चुनौती है! जब तक तुम हार नहीं मानते, तब तक तुम हारे नहीं हो। डर के आगे बढ़ो, उससे लड़ो, क्योंकि जीत उसी की होती है जो डर को हरा देता है। डरो मत, उड़ान भरो!','output/kumdshivam524@gmail.com/videos/fear_20250729060830_hi_video.mp4','output/kumdshivam524@gmail.com/temp/fear_20250729060830_hi_mixed.m4a','output/kumdshivam524@gmail.com/images/fear_20250729060830_hi_text_image.png','fear_20250729060830','hi',0,NULL,'2025-07-29 11:44:40','instagram','posted','Posted to IG: https://www.instagram.com/reel/DMrmYZxOzRB/','2025-07-29 06:11:24','2025-07-29 06:14:40'),(29,4,'Moriga Power Ke Liye Advertiment Jisshe Project Sell Ho 20250729064542','जिंदगी की हर रेस में, आपको चाहिए मोरिगा पावर! ये वो जादू है जो हर प्रोजेक्ट को बना देगा हिट! चाहे बिज़नेस हो या पर्सनल गोल, मोरिगा आपकी एनर्जी, आपका कॉन्फिडेंस बढ़ाएगा! देखिए कैसे ये सुपरफूड बदल रहा है लोगों की जिंदगी! अभी ट्राई करें और महसूस करें अंतर! मोरिगा पावर—सफलता का आपका नया सीक्रेट!','जिंदगी की हर रेस में, आपको चाहिए मोरिगा पावर! ये वो जादू है जो हर प्रोजेक्ट को बना देगा हिट! चाहे बिज़नेस हो या पर्सनल गोल, मोरिगा आपकी एनर्जी, आपका कॉन्फिडेंस बढ़ाएगा! देखिए कैसे ये सुपरफूड बदल रहा है लोगों की जिंदगी! अभी ट्राई करें और महसूस करें अंतर! मोरिगा पावर—सफलता का आपका नया सीक्रेट!','output/kumdshivam524@gmail.com/videos/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_20250729064542_hi_video.mp4','output/kumdshivam524@gmail.com/temp/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_20250729064542_hi_mixed.m4a','output/kumdshivam524@gmail.com/images/moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_20250729064542_hi_text_image.png','moriga_power_ke_liye_advertiment_jisshe_project_sell_ho_20250729064542','hi',0,NULL,'2025-07-29 12:22:47','instagram','posted','Posted to IG: https://www.instagram.com/reel/DMrqu3aNhcS/','2025-07-29 06:49:57','2025-07-29 06:52:47'),(30,4,'Moringa Power Ke Liye Advertiment Reel 20250729095922','Unlock nature’s superpower with Moringa! Packed with vitamins, energy, and strength—this tiny leaf is your daily dose of unstoppable. Feel the difference, fuel your body, and conquer your day! Moringa—because you deserve nothing but the best. Power up now!','Unlock nature’s superpower with Moringa! Packed with vitamins, energy, and strength—this tiny leaf is your daily dose of unstoppable. Feel the difference, fuel your body, and conquer your day! Moringa—because you deserve nothing but the best. Power up now!','output/kumdshivam524@gmail.com/videos/MORINGA_power_ke_liye_advertiment_reel_20250729095922_en_video.mp4','output/kumdshivam524@gmail.com/temp/MORINGA_power_ke_liye_advertiment_reel_20250729095922_en_mixed.m4a','output/kumdshivam524@gmail.com/images/MORINGA_power_ke_liye_advertiment_reel_20250729095922_en_text_image.png','MORINGA_power_ke_liye_advertiment_reel_20250729095922','en',0,NULL,'2025-07-29 15:35:42','instagram','posted','Posted to IG: https://www.instagram.com/reel/DMsA0hQNsBj/','2025-07-29 10:02:32','2025-07-29 10:05:42'),(31,4,'Discipline 20250731102211','मोटिवेशन खत्म हो सकता है — लेकिन अनुशासन हमेशा साथ देता है। हर दिन डटे रहो — चाहे मन करे या नहीं। यहीं से चैंपियंस बनते हैं। महानता शोर नहीं मचाती — वो आदत बन जाती है।','मोटिवेशन खत्म हो सकता है — लेकिन अनुशासन हमेशा साथ देता है। हर दिन डटे रहो — चाहे मन करे या नहीं। यहीं से चैंपियंस बनते हैं। महानता शोर नहीं मचाती — वो आदत बन जाती है।','output/kumdshivam524@gmail.com/videos/discipline_20250731102211_hi_video.mp4','output/kumdshivam524@gmail.com/temp/discipline_20250731102211_hi_mixed.m4a','output/kumdshivam524@gmail.com/images/discipline_20250731102211_hi_text_image.png','discipline_20250731102211','hi',0,NULL,NULL,'instagram','draft',NULL,'2025-07-31 04:55:22','2025-07-31 04:55:22'),(32,4,'Discipline 20250731102949','ज़िंदगी में कुछ बड़ा पाना है? तो लगाओ मेहनत, पर सिर्फ मेहनत काफी नहीं!  \r\nरोज़ उठो, संघर्ष करो, खुद को दोहराओ – यही अनुशासन है!  \r\nथकान होगी, मन मानेगा नहीं, पर जीत उसी की है जो हार नहीं मानता!  \r\nएक दिन वो खुद हैरान रह जाएगा – देखो कैसे छोटे-छोटे अनुशासन ने बड़े सपने बना दिए!  \r\nचलो, आज से ही शुरू करो – कल का इंतज़ार मत करो!','ज़िंदगी में कुछ बड़ा पाना है? तो लगाओ मेहनत, पर सिर्फ मेहनत काफी नहीं!  \r\nरोज़ उठो, संघर्ष करो, खुद को दोहराओ – यही अनुशासन है!  \r\nथकान होगी, मन मानेगा नहीं, पर जीत उसी की है जो हार नहीं मानता!  \r\nएक दिन वो खुद हैरान रह जाएगा – देखो कैसे छोटे-छोटे अनुशासन ने बड़े सपने बना दिए!  \r\nचलो, आज से ही शुरू करो – कल का इंतज़ार मत करो!','output/kumdshivam524@gmail.com/videos/discipline_20250731102949_hi_video.mp4','output/kumdshivam524@gmail.com/temp/discipline_20250731102949_hi_mixed.m4a','output/kumdshivam524@gmail.com/images/discipline_20250731102949_hi_text_image.png','discipline_20250731102949','hi',0,NULL,NULL,'instagram','draft',NULL,'2025-07-31 05:04:46','2025-07-31 05:04:46');
/*!40000 ALTER TABLE `reels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedules`
--

DROP TABLE IF EXISTS `schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schedules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `reel_id` int NOT NULL,
  `scheduled_for` datetime DEFAULT NULL,
  `timezone` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `retry_count` int NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `error_log` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `reel_id` (`reel_id`),
  KEY `idx_schedule_status` (`status`),
  KEY `idx_schedule_time` (`scheduled_for`),
  KEY `idx_schedule_user` (`user_id`),
  CONSTRAINT `schedules_ibfk_1` FOREIGN KEY (`reel_id`) REFERENCES `reels` (`id`),
  CONSTRAINT `schedules_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `schedules_chk_1` CHECK ((`status` in (_utf8mb4'pending',_utf8mb4'processing',_utf8mb4'posted',_utf8mb4'failed')))
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedules`
--

LOCK TABLES `schedules` WRITE;
/*!40000 ALTER TABLE `schedules` DISABLE KEYS */;
INSERT INTO `schedules` VALUES (4,2,4,NULL,'Asia/Kolkata',0,'pending',NULL,'2025-07-24 15:52:38','2025-07-24 15:52:38'),(5,2,5,'2025-07-24 10:04:00','Asia/Kolkata',0,'posted',NULL,'2025-07-24 16:02:52','2025-07-25 06:31:34'),(6,4,7,'2025-07-24 11:44:00','Asia/Kolkata',0,'posted',NULL,'2025-07-25 04:56:47','2025-07-25 06:17:36'),(7,4,8,'2025-07-24 12:14:00','Asia/Kolkata',0,'posted',NULL,'2025-07-25 06:35:48','2025-07-25 06:50:10'),(11,4,12,'2025-07-25 18:10:00','Asia/Kolkata',0,'posted',NULL,'2025-07-25 12:34:11','2025-07-25 12:40:39'),(12,4,13,'2025-07-25 18:12:00','Asia/Kolkata',0,'posted',NULL,'2025-07-25 12:39:34','2025-07-25 12:42:37'),(13,5,14,NULL,'Asia/Kolkata',0,'pending',NULL,'2025-07-25 14:50:40','2025-07-25 14:50:40'),(14,5,15,NULL,'Asia/Kolkata',0,'pending',NULL,'2025-07-25 14:52:31','2025-07-25 14:52:31'),(15,1,16,'2025-07-26 09:00:00','Asia/Kolkata',0,'posted',NULL,'2025-07-25 21:43:52','2025-07-26 03:30:36'),(16,1,17,'2025-07-26 08:00:00','Asia/Kolkata',0,'posted',NULL,'2025-07-25 21:49:06','2025-07-26 02:30:37'),(17,1,18,'2025-07-26 07:00:00','Asia/Kolkata',0,'posted',NULL,'2025-07-25 21:55:55','2025-07-26 01:30:34'),(18,2,19,'2025-07-28 10:56:00','Asia/Kolkata',0,'posted',NULL,'2025-07-27 07:11:36','2025-07-28 08:51:27'),(19,4,20,'2025-07-27 22:40:00','Asia/Kolkata',0,'posted',NULL,'2025-07-27 17:06:40','2025-07-27 17:11:48'),(20,4,27,'2025-07-28 11:09:00','Asia/Kolkata',0,'posted',NULL,'2025-07-28 05:36:20','2025-07-28 08:52:07'),(21,4,26,'2025-07-28 16:22:00','Asia/Kolkata',0,'posted',NULL,'2025-07-28 10:51:11','2025-07-28 10:52:40'),(22,4,25,'2025-07-28 16:28:00','Asia/Kolkata',0,'posted',NULL,'2025-07-28 10:51:24','2025-07-28 10:58:59'),(23,4,24,'2025-07-28 16:35:00','Asia/Kolkata',0,'posted',NULL,'2025-07-28 10:51:41','2025-07-28 11:05:37'),(24,4,28,'2025-07-29 11:44:00','Asia/Kolkata',0,'posted',NULL,'2025-07-29 06:11:24','2025-07-29 06:14:40'),(25,4,29,'2025-07-29 12:22:00','Asia/Kolkata',0,'posted',NULL,'2025-07-29 06:49:57','2025-07-29 06:52:47'),(26,4,30,'2025-07-29 15:35:00','Asia/Kolkata',0,'posted',NULL,'2025-07-29 10:02:32','2025-07-29 10:05:42'),(27,4,31,'2025-07-31 10:35:00','Asia/Kolkata',0,'pending',NULL,'2025-07-31 04:55:22','2025-07-31 04:58:50'),(28,4,32,'2025-07-31 10:45:00','Asia/Kolkata',0,'pending',NULL,'2025-07-31 05:04:46','2025-07-31 05:05:34');
/*!40000 ALTER TABLE `schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `themes`
--

DROP TABLE IF EXISTS `themes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `themes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lang` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_theme_name_lang` (`name`,`lang`),
  KEY `idx_themes_name_lang` (`name`,`lang`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `themes`
--

LOCK TABLES `themes` WRITE;
/*!40000 ALTER TABLE `themes` DISABLE KEYS */;
INSERT INTO `themes` VALUES (1,'motivation','en','Don’t wait for the perfect moment. Start now. Even small steps matter. You’re not weak — you’re growing. Keep going. Greatness is built one rep at a time. No one starts perfect — they just start. Every legend once stood where you’re standing now. It’s your time.'),(2,'motivation','hi','सही समय का इंतज़ार मत करो — अभी शुरू करो। हर छोटा कदम मायने रखता है। तुम कमज़ोर नहीं, बस बढ़ रहे हो। जारी रखो — यही सफलता का रास्ता है। कोई भी परफेक्ट नहीं शुरू करता — वो बस शुरू करता है। हर महान कहानी यहीं से शुरू होती है — अब तुम्हारी बारी है।'),(3,'success','en','Success doesn’t come overnight. It’s built on failure, grit, and relentless effort. Don’t chase money — chase excellence. The results will follow. Keep your focus, trust the process, and outwork yesterday. Even on tough days, progress is progress.'),(4,'success','hi','सफलता एक दिन में नहीं मिलती। ये मेहनत, धैर्य और जुनून से बनती है। पैसे के पीछे मत भागो — कमाल करो, पैसा खुद आएगा। प्रक्रिया पर भरोसा रखो और हर दिन थोड़ा बेहतर बनो। मुश्किल दिनों में भी आगे बढ़ना ही जीत है।'),(5,'inspiration','en','Every great story begins with a dream. You don’t need permission to shine. Your journey is yours — embrace it. Light your own fire. And remember: stars shine brightest in the dark. So when it’s tough — that’s when you rise.'),(6,'inspiration','hi','हर बड़ी कहानी एक सपने से शुरू होती है। चमकने के लिए किसी की इजाज़त मत लो। ये सफ़र तुम्हारा है — इसे अपनाओ। अपनी चिंगारी खुद बनो। और याद रखो — अंधेरे में ही सितारे सबसे तेज़ चमकते हैं। मुश्किल वक्त ही तुम्हारी असली पहचान बनाता है।'),(7,'life','en','Life isn’t a race. Breathe. Be present. The most beautiful moments are often quiet and simple. Don’t miss them chasing noise. Slow down and feel — joy lives in the now, not someday. Make time for what matters.'),(8,'life','hi','ज़िंदगी कोई दौड़ नहीं है। सांस लो, अभी में जियो। सबसे खूबसूरत पल अक्सर सादे होते हैं — उन्हें मत खोना, भागदौड़ में। रुककर महसूस करो — सच्ची खुशी ’अभी’ में छुपी होती है, किसी भविष्य में नहीं। जो ज़रूरी है, उसके लिए वक़्त निकालो।'),(9,'confidence','en','Real confidence doesn’t shout. It shows. You don’t need to prove yourself to anyone. Walk your path. Your energy speaks louder than words. Trust your steps — the world adjusts when you do.'),(10,'confidence','hi','सच्चा आत्मविश्वास चिल्लाता नहीं — दिखता है। किसी को कुछ साबित करने की ज़रूरत नहीं। अपना रास्ता चुनो — तुम्हारी ऊर्जा खुद बोलेगी। अपने फैसलों पर भरोसा रखो — जब तुम बदलते हो, दुनिया अपने आप रास्ता देती है।'),(11,'discipline','en','Motivation fades. But discipline? That’s your armor. Show up daily — even when it’s boring, even when it’s hard. That’s how champions are made. Greatness isn’t loud — it’s consistent.'),(12,'discipline','hi','मोटिवेशन खत्म हो सकता है — लेकिन अनुशासन हमेशा साथ देता है। हर दिन डटे रहो — चाहे मन करे या नहीं। यहीं से चैंपियंस बनते हैं। महानता शोर नहीं मचाती — वो आदत बन जाती है।'),(13,'gratitude','en','Gratitude is a superpower. It grounds you. Reminds you of what you have, not what’s missing. Want to be happier? Start saying thank you more. Count blessings, not burdens — that’s real abundance.'),(14,'gratitude','hi','कृतज्ञता ताकत देती है। ये तुम्हें जोड़ती है — जो है, उसे देखने की आदत डालती है। ज़्यादा खुश रहना है? रोज़ शुक्रिया कहना शुरू करो। कमियों पर नहीं — जो मिला है उस पर ध्यान दो। यही असली संपन्नता है।'),(15,'fear','en','Fear will always whisper — ’you can’t.’ But you’re stronger than your doubt. Take the step anyway. Your courage is louder than fear. Every bold action weakens fear’s grip. Keep moving forward.'),(16,'fear','hi','डर हमेशा कहेगा — ’तू नहीं कर सकता।’ पर तुम उससे ज़्यादा ताकतवर हो। एक कदम बढ़ाओ — साहस की आवाज़ डर से ऊँची होती है। हर हिम्मती कदम डर की पकड़ को कमजोर करता है। चलते रहो।'),(17,'cosmetics','en','Does your skin feel tired and lifeless? It’s time to try something new! Introducing GlowMist — a hydrating facial spray that gives instant freshness and a natural glow. Infused with rose water, hyaluronic acid, and 100% cruelty-free. Just one spray… and your skin says WOW! ✨ Want glowing skin 24/7? This is your sign. Order now — link in bio!'),(18,'cosmetics','hi','क्या आपकी त्वचा थकी हुई और बेजान लगती है? अब वक्त है कुछ नया ट्राय करने का! पेश है GlowMist — एक हाइड्रेटिंग फेस स्प्रे जो देता है इंस्टेंट ताज़गी और नेचुरल ग्लो। गुलाब जल, हायालुरोनिक एसिड और 100% क्रूएल्टी-फ्री फॉर्मूला। बस एक स्प्रे… और आपकी त्वचा बोले – वॉव! ✨ 24x7 ग्लो चाहिए? तो बस ये इस्तेमाल करें — ऑर्डर करें अभी, लिंक बायो में है!');
/*!40000 ALTER TABLE `themes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_tokens`
--

DROP TABLE IF EXISTS `user_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `access_token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `refresh_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `platform` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `platform_user_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_id_platform` (`user_id`,`platform`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_tokens`
--

LOCK TABLES `user_tokens` WRITE;
/*!40000 ALTER TABLE `user_tokens` DISABLE KEYS */;
INSERT INTO `user_tokens` VALUES (1,1,'EAASKZA7DgRoYBPAdBHCugqZCZC9xHGugEwptxqCkztoRapVRLKhZCDa0EdchKEGIsJnLsJbSGecU13fyPe1uVbnUUJbIuw96FqCozBmZBZBahPp3rgcy3aBvZA6rnFD5XSswEfZBCvrlxrwLZCBLKylsPHZCqLeVa5KqQJT5d7je8JU0pB5Bz9qFCCc6hrTu9yOAjo','','2025-09-25 11:57:34','instagram','17841475471127528','2025-07-24 11:28:01','2025-07-27 11:57:34'),(2,2,'EAASKZA7DgRoYBPHqhXLZBrXf0dwb42F9ZB3BMhYZCT8g1Vt9hvINDAjfMmesaphTM1uEHztYgPosifditqysXrUN5BUryZBzCUpRlw3R8vxblHJpJQTmsbb5ZBWwVT0UOMNq8qKQih3s2fT6sBLMuVlDed33hwIuZCt1uDJS6KXRKYQZC8EC6BMmZAmAu2GtnTagR','','2025-09-23 05:59:32','instagram','17841474761153349','2025-07-25 05:59:32','2025-07-25 05:59:32'),(3,4,'EAASKZA7DgRoYBPG5Ud5zpC03Ygnb0iWOXEQE0y1n2OTEZBNT8OZAJgfTJDwYmcgypEobCQ6ZBqVRIs7Sn9T5wiQ5WloEiq2v5gJhenBTrHkOBeCSgFGSIWHb9SoKa1f5ckM7ZBvAHOFUvGlyLGxO5gCXjJo8yXEBTwdZATshWvwfZCTWIEbFcGyYqyZCaWZCx','','2025-09-27 06:08:01','instagram','17841474761153349','2025-07-25 06:00:20','2025-07-29 06:08:01');
/*!40000 ALTER TABLE `user_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `plan` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_admin` tinyint(1) NOT NULL,
  `email_verified` tinyint(1) NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'developer@sazm.in','scrypt:32768:8:1$OeZJz9p2KUYKbWGh$8a6c8bb295d6077ac3aed46d06886f747b21463e54b3fbbec7fe5aa7f7d80721af7796d0645f4fd15bb80684a1ef9f8560214062968f18abb9a16528c1b24a69','Business',1,1,NULL,'2025-07-24 09:01:08','2025-07-24 09:02:52'),(2,'shivamkumr132@gmail.com','scrypt:32768:8:1$x8WXJYWd0UrjYWtt$e8270eab990d2de89d29e0c2252992a6b296c36444a0e5c07b49fee252d1a7ed1b623f5ecfc4f5fee7ab3ae9f6903177805600a138ca847e277bee5106959922','Business',1,1,NULL,'2025-07-24 09:01:08','2025-07-24 09:01:08'),(3,'smkrgeid@gmail.com','scrypt:32768:8:1$xZCeo0oDtrFkXkX2$7ee07a8e4bfacc97b21602715095644af1f341968c94158d1835590558bf875779c9e37e0c44a4598506f6502d11627511906ab905fbddc31b5b9d22487baae2','Free',0,0,NULL,'2025-07-24 15:31:50','2025-07-24 15:31:50'),(4,'kumdshivam524@gmail.com','scrypt:32768:8:1$UTFwrJeDmO5ZRLxd$116e3b3b2893b13937f388ef4b4d0e25903ac8d1778dc4f8e11812c5e23a8a6cd86e94952bda731e6b20d086eec37eb7a0e90d0148982600190d2ee406e4f3c7','Free',0,0,NULL,'2025-07-25 04:49:05','2025-07-25 04:49:05'),(5,'bharatjidubey021@gmail.com','scrypt:32768:8:1$HydJAoUCs6sedpHL$41e380ea7158507f42d4aa12885b79784bbcfb4823e7872dc0334fad414aa82ff0ca95b247b8ea685d5c81b4f5f33ef6f43e92d099a20655b21863aa40b38af5','Free',0,0,NULL,'2025-07-25 14:46:05','2025-07-25 14:46:05');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-31 16:01:26
